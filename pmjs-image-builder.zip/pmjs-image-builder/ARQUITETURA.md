# Arquitetura

O `build-image.sh` é somente o orquestrador: carrega configuração e módulos,
instala os traps, encadeia as validações, solicita a geração e apresenta o
resultado.

## Módulos

- `lib/ui.sh`: cabeçalho e mensagens de informação, sucesso, aviso e erro.
- `lib/logs.sh`: inicialização, escrita e consulta do caminho do log.
- `lib/checks.sh`: privilégios, dependências, configuração, diretórios, espaço
  livre e isolamento do filesystem de destino.
- `lib/rootfs.sh`: montagem do comando GNU tar, geração e validação do rootfs.

## Fluxo

1. Validar root e dependências básicas.
2. Carregar `config/image.conf` e conferir a versão com `VERSION`.
3. Inicializar o log e validar origem, diretórios e espaço livre.
4. Criar `output/pmjs-linux-<versão>/`.
5. Confirmar que esse destino e `/` têm device IDs diferentes.
6. Gerar `rootfs.tar.gz.partial` com GNU tar.
7. Validar gzip, listagem tar e exclusões obrigatórias.
8. Renomear atomicamente o arquivo temporário para `rootfs.tar.gz`.
9. Exibir arquivo, tamanho, duração e log.

O trap de saída remove somente o `.partial`. O archive anterior, se existir,
só é substituído após a nova captura ser validada.

## Captura

O tar usa `--numeric-owner`, `--acls`, `--xattrs` e `--one-file-system`.
Conteúdos voláteis ou fora do escopo são excluídos com padrões `diretório/*`;
assim, o próprio diretório vazio permanece no archive quando existe. A saída é
excluída explicitamente, além da separação obrigatória de filesystem.

Não há snapshot nesta sprint. Arquivos modificados durante a leitura podem
causar falha ou produzir uma visão temporalmente inconsistente.
